﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinhVien
{
    public class ListSinhVien
    {
       private static ListSinhVien instance;
        List<Sinhvien> listSinhVien;
        public static ListSinhVien Instance { 
            get
            {
                if (instance == null)
                    instance = new ListSinhVien();
                  return instance;
             }
          
            set => instance  = value;
        }
        public List<Sinhvien> ListSinhVien { get => listSinhVien; set => listSinhVien = value; }
        private ListSinhVien()
        {
            listSinhVien=new List<Sinhvien>();
            listSinhVien.Add(new Sinhvien("Tan Phuc", new DateTime(2000, 3, 14), "Ho Chi Minh city"));
            listSinhVien.Add(new Sinhvien("Chi Luan", new DateTime(2000,3,7), "Ca Mau province"));
            listSinhVien.Add(new SinhVien("Hoang Phuc"), new DateTime(1999, 2, 13, "Dong Thap province"));
        }
    }
}
 
